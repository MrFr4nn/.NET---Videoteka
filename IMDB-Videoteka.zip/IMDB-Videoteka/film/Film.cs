﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace film
{
    public class Film
    {
        public int FilmID { get; set; }
        public string Naslov { get; set; }
        public int GodinaIzdanja { get; set; }
        public bool NaStanju { get; set; }
        public int Recenzija { get; set; }
        public string Poster { get; set; }

        public virtual ICollection<Posudba> Posudbe { get; set; }
    }

    public class Korisnik
    {
        public int KorisnikID { get; set; }
        public string Ime { get; set; }
        public string Prezime { get; set; }

        public virtual ICollection<Posudba> Posudbe { get; set; }
    }

    public class Posudba
    {
        public int PosudbaID { get; set; }
        public int KorisnikID { get; set; }
        public int FilmID { get; set; }
        public bool Posuđen { get; set; }

        public virtual Korisnik Korisnik { get; set; }
        public virtual Film Film { get; set; }
    }
}