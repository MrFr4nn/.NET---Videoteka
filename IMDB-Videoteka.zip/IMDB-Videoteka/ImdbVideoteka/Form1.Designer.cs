﻿namespace ImdbVideoteka
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnpretraga = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tboxpretraga = new System.Windows.Forms.TextBox();
            this.lvFilmovi = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pbFilmovi = new System.Windows.Forms.PictureBox();
            this.btnObrisiPosudbu = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnIzvjesce = new System.Windows.Forms.Button();
            this.btnVraceno = new System.Windows.Forms.Button();
            this.btnAzuriraj = new System.Windows.Forms.Button();
            this.btnPosudiFilm = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.cbSortiraj = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbFilmovi)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(916, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(240, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "PIN-VIDEOTEKA";
            // 
            // btnpretraga
            // 
            this.btnpretraga.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnpretraga.Location = new System.Drawing.Point(1258, 72);
            this.btnpretraga.Name = "btnpretraga";
            this.btnpretraga.Size = new System.Drawing.Size(155, 24);
            this.btnpretraga.TabIndex = 3;
            this.btnpretraga.Text = "PRETRAŽI";
            this.btnpretraga.UseVisualStyleBackColor = false;
            this.btnpretraga.Click += new System.EventHandler(this.btnpretraga_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(772, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Naslov:";
            // 
            // tboxpretraga
            // 
            this.tboxpretraga.Location = new System.Drawing.Point(845, 74);
            this.tboxpretraga.Name = "tboxpretraga";
            this.tboxpretraga.Size = new System.Drawing.Size(398, 22);
            this.tboxpretraga.TabIndex = 5;
            this.tboxpretraga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tboxpretraga_KeyPress);
            // 
            // lvFilmovi
            // 
            this.lvFilmovi.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvFilmovi.FullRowSelect = true;
            this.lvFilmovi.GridLines = true;
            this.lvFilmovi.HideSelection = false;
            this.lvFilmovi.Location = new System.Drawing.Point(893, 130);
            this.lvFilmovi.Name = "lvFilmovi";
            this.lvFilmovi.Size = new System.Drawing.Size(292, 275);
            this.lvFilmovi.TabIndex = 6;
            this.lvFilmovi.UseCompatibleStateImageBehavior = false;
            this.lvFilmovi.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Godina izdanja";
            this.columnHeader1.Width = 105;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Naslov";
            this.columnHeader2.Width = 180;
            // 
            // pbFilmovi
            // 
            this.pbFilmovi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbFilmovi.Location = new System.Drawing.Point(1191, 130);
            this.pbFilmovi.Name = "pbFilmovi";
            this.pbFilmovi.Size = new System.Drawing.Size(222, 275);
            this.pbFilmovi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFilmovi.TabIndex = 7;
            this.pbFilmovi.TabStop = false;
            // 
            // btnObrisiPosudbu
            // 
            this.btnObrisiPosudbu.BackColor = System.Drawing.Color.OrangeRed;
            this.btnObrisiPosudbu.Location = new System.Drawing.Point(23, 188);
            this.btnObrisiPosudbu.Name = "btnObrisiPosudbu";
            this.btnObrisiPosudbu.Size = new System.Drawing.Size(170, 59);
            this.btnObrisiPosudbu.TabIndex = 15;
            this.btnObrisiPosudbu.Text = "IZBRIŠI POSUDBU";
            this.btnObrisiPosudbu.UseVisualStyleBackColor = false;
            this.btnObrisiPosudbu.Click += new System.EventHandler(this.btnObrisiPosudbu_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightGray;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1874, 60);
            this.panel1.TabIndex = 23;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightGray;
            this.panel2.Controls.Add(this.btnIzvjesce);
            this.panel2.Controls.Add(this.btnVraceno);
            this.panel2.Controls.Add(this.btnAzuriraj);
            this.panel2.Controls.Add(this.btnPosudiFilm);
            this.panel2.Controls.Add(this.btnObrisiPosudbu);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 60);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(225, 763);
            this.panel2.TabIndex = 24;
            // 
            // btnIzvjesce
            // 
            this.btnIzvjesce.BackColor = System.Drawing.Color.CadetBlue;
            this.btnIzvjesce.Location = new System.Drawing.Point(23, 470);
            this.btnIzvjesce.Name = "btnIzvjesce";
            this.btnIzvjesce.Size = new System.Drawing.Size(170, 59);
            this.btnIzvjesce.TabIndex = 29;
            this.btnIzvjesce.Text = "KREIRAJ IZVJEŠĆE";
            this.btnIzvjesce.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnIzvjesce.UseVisualStyleBackColor = false;
            this.btnIzvjesce.Click += new System.EventHandler(this.btnIzvjesce_Click);
            // 
            // btnVraceno
            // 
            this.btnVraceno.BackColor = System.Drawing.Color.Orange;
            this.btnVraceno.Location = new System.Drawing.Point(23, 283);
            this.btnVraceno.Name = "btnVraceno";
            this.btnVraceno.Size = new System.Drawing.Size(170, 59);
            this.btnVraceno.TabIndex = 28;
            this.btnVraceno.Text = "VRATI FILM";
            this.btnVraceno.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnVraceno.UseVisualStyleBackColor = false;
            this.btnVraceno.Click += new System.EventHandler(this.btnVraceno_Click);
            // 
            // btnAzuriraj
            // 
            this.btnAzuriraj.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAzuriraj.Location = new System.Drawing.Point(23, 378);
            this.btnAzuriraj.Name = "btnAzuriraj";
            this.btnAzuriraj.Size = new System.Drawing.Size(170, 59);
            this.btnAzuriraj.TabIndex = 26;
            this.btnAzuriraj.Text = "AŽURIRAJ PODATKE";
            this.btnAzuriraj.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnAzuriraj.UseVisualStyleBackColor = false;
            this.btnAzuriraj.Click += new System.EventHandler(this.btnAzuriraj_Click);
            // 
            // btnPosudiFilm
            // 
            this.btnPosudiFilm.BackColor = System.Drawing.Color.Lime;
            this.btnPosudiFilm.Location = new System.Drawing.Point(23, 97);
            this.btnPosudiFilm.Name = "btnPosudiFilm";
            this.btnPosudiFilm.Size = new System.Drawing.Size(170, 59);
            this.btnPosudiFilm.TabIndex = 24;
            this.btnPosudiFilm.Text = "POSUDI FILM";
            this.btnPosudiFilm.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnPosudiFilm.UseVisualStyleBackColor = false;
            this.btnPosudiFilm.Click += new System.EventHandler(this.btnPosudiFilm_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(318, 476);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1544, 335);
            this.dataGridView1.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(241, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 16);
            this.label3.TabIndex = 26;
            this.label3.Text = "Sortiraj po:";
            // 
            // cbSortiraj
            // 
            this.cbSortiraj.FormattingEnabled = true;
            this.cbSortiraj.Location = new System.Drawing.Point(318, 138);
            this.cbSortiraj.Name = "cbSortiraj";
            this.cbSortiraj.Size = new System.Drawing.Size(194, 24);
            this.cbSortiraj.TabIndex = 27;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(1874, 823);
            this.Controls.Add(this.cbSortiraj);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pbFilmovi);
            this.Controls.Add(this.lvFilmovi);
            this.Controls.Add(this.tboxpretraga);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnpretraga);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbFilmovi)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnpretraga;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tboxpretraga;
        private System.Windows.Forms.ListView lvFilmovi;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.PictureBox pbFilmovi;
        private System.Windows.Forms.Button btnObrisiPosudbu;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnPosudiFilm;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnAzuriraj;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbSortiraj;
        private System.Windows.Forms.Button btnIzvjesce;
        private System.Windows.Forms.Button btnVraceno;
    }
}

