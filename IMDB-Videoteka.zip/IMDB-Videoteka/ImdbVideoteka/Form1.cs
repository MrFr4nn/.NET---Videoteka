﻿using RestSharp;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Net.Mail;
using System.Data.Common;
using System.Globalization;

namespace ImdbVideoteka
{
    public partial class Form1 : Form
    {
        private const string ConnString = "Data Source=DESKTOP-II09MBM;Initial Catalog=PinVideoteka;Integrated Security=True;";
        private List<Search> filmovi;
        private Search odabraniFilm;

        public Form1()
        {
            InitializeComponent();
            lvFilmovi.SelectedIndexChanged += lvFilmovi_SelectedIndexChanged;
            UcitajPodatke();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbSortiraj.Items.AddRange(dobijNaziveStupaca().ToArray());
            cbSortiraj.SelectedIndex = 0;
            cbSortiraj.SelectedIndexChanged += cbSortiraj_SelectedIndexChanged;
            UcitajPodatke();
        }

        private List<string> dobijNaziveStupaca()
        {
            List<string> odabraniStupci = new List<string>();
            string[] predefiniraniStupci = { "FilmID", "Naslov", "GodinaIzdanja", "KorisnikID", "Posuđen", "Ime", "Prezime", "Email", "DatumPosudbe", "DatumVracanja", "DatumVraceno", "Ocjena" };
            odabraniStupci.AddRange(predefiniraniStupci.Where(col => col.StartsWith("Korisnik")));
            odabraniStupci.AddRange(predefiniraniStupci.Where(col => !col.StartsWith("Korisnik"))); 

            return odabraniStupci;
        }


        private void UcitajPodatke()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnString))
                {
                    connection.Open();
                    string odabraniStupac = cbSortiraj.SelectedItem?.ToString();
                    if (odabraniStupac != null)
                    {
                        string query = $@"
                        SELECT
                            Film.FilmID,
                            Film.Naslov,
                            Film.GodinaIzdanja,
                            Film.Posuđen,
                            Korisnik.KorisnikID,
                            Korisnik.Ime,  
                            Korisnik.Prezime,  
                            Korisnik.Email, 
                            Posudba.DatumPosudbe,
                            Posudba.DatumVracanja,
                            Posudba.DatumVraceno,
                            Recenzija.Ocjena
                        FROM
                            Film
                        LEFT JOIN Posudba ON Film.FilmID = Posudba.FilmID
                        LEFT JOIN Korisnik ON Posudba.KorisnikID = Korisnik.KorisnikID
                        LEFT JOIN Recenzija ON Film.FilmID = Recenzija.FilmID
                        ORDER BY {odabraniStupac} ASC";

                        using (SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection))
                        {
                            DataTable dataTable = new DataTable();
                            dataAdapter.Fill(dataTable);
                            dataGridView1.DataSource = dataTable;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri učitavanju podataka: " + ex.Message);
            }
        }

        private void dataGridView1_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                List<string> stupciZaAzuriranje = new List<string> { "Naslov", "GodinaIzdanja", "KorisnikIme", "KorisnikPrezime", "KorisnikEmail", "DatumPosudbe", "DatumVracanja", "Ocjena" };

                using (SqlConnection connection = new SqlConnection(ConnString))
                {
                    connection.Open();
                    string primarniKljucNazivStupca = "FilmID";
                    object primarniKljucObjektVrijednosti = row.Cells[primarniKljucNazivStupca].Value;

                    if (primarniKljucObjektVrijednosti != null)
                    {
                        string primarnikljucVrijednost = primarniKljucObjektVrijednosti.ToString();

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (!stupciZaAzuriranje.Contains(cell.OwningColumn.Name))
                                continue;

                            string nazivStupca = cell.OwningColumn.Name;
                            string trenutnaVrijednost = cell.Value?.ToString() ?? string.Empty;
                            string updateQuery = $"UPDATE Film SET {nazivStupca} = @NewValue WHERE {primarniKljucNazivStupca} = @PrimaryKeyValue";
                            using (SqlCommand command = new SqlCommand(updateQuery, connection))
                            {
                                command.Parameters.AddWithValue("@NewValue", trenutnaVrijednost);
                                command.Parameters.AddWithValue("@PrimaryKeyValue", primarnikljucVrijednost);
                                command.ExecuteNonQuery();
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Pogreška: Nije moguće odrediti vrijednost primarnog ključa.");
                    }
                }
                dataGridView1.Refresh();
            }
        }

        private void cbSortiraj_SelectedIndexChanged(object sender, EventArgs e)
        {
            UcitajPodatke();
        }

        private void btnpretraga_Click(object sender, EventArgs e)
        {
            string kljucnaRijec = tboxpretraga.Text;
            RestClient client = new RestClient("http://www.omdbapi.com");
            RestRequest request = new RestRequest("/?apikey=6ad74903&type=movie&s=" + kljucnaRijec);

            var rezultat = client.Execute<RootTrailer>(request, Method.Get);

            if (rezultat.ResponseStatus != ResponseStatus.Completed || !rezultat.IsSuccessful)
            {
                MessageBox.Show("Pogreška prilikom pretrage. Molimo pokušajte ponovo.");
                return;
            }

           
            if (rezultat.Data != null && rezultat.Data.Search != null && rezultat.Data.Search.Any())
            {
                filmovi = rezultat.Data.Search;
                lvFilmovi.Items.Clear();
                foreach (var film in rezultat.Data.Search)
                {
                    lvFilmovi.Items.Add(new ListViewItem(new string[] { film.Year, film.Title }));
                }
            }
            else
            {
                MessageBox.Show("Nema pronađenih filmova za uneseni pojam. Molimo pokušajte ponovo s drugim pojmom.");
            }
        }

        private void tboxpretraga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnpretraga_Click(null, null);
            }
        }

        private void PrikaziPoster(string posterUrl)
        {
            pbFilmovi.ImageLocation = posterUrl;
        }

        private void lvFilmovi_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvFilmovi.SelectedItems.Count > 0)
            {
                int selectedIndex = lvFilmovi.SelectedIndices[0];
                odabraniFilm = filmovi[selectedIndex];
                PrikaziPoster(odabraniFilm.Poster);
                UcitajPodatke();
            }
        }

        private int provjeriPostojiLiKorisnik(SqlConnection connection, string[] userParts)
        {
            string provjeriKorisnickiQuery = "SELECT KorisnikID FROM Korisnik WHERE Ime = @Ime AND Prezime = @Prezime AND Email = @Email";

            using (SqlCommand command = new SqlCommand(provjeriKorisnickiQuery, connection))
            {
                command.Parameters.AddWithValue("@Ime", userParts[0]);
                command.Parameters.AddWithValue("@Prezime", userParts[1]);
                command.Parameters.AddWithValue("@Email", userParts[2]);

                object rezultat = command.ExecuteScalar();

                if (rezultat != null)
                {
                    return Convert.ToInt32(rezultat);
                }
                else
                {
                    return -1;
                }
            }
        }

        private int dobijZadnjiUmetnutiID(SqlConnection connection)
        {
            string query = "SELECT IDENT_CURRENT('Korisnik') AS LastID";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                object rezultat = command.ExecuteScalar();
                return rezultat == null || rezultat == DBNull.Value ? 0 : Convert.ToInt32(rezultat);
            }
        }

        private void btnObrisiPosudbu_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    string filmID = dataGridView1.SelectedRows[0].Cells["FilmID"].Value.ToString();

                    using (SqlConnection connection = new SqlConnection(ConnString))
                    {
                        connection.Open();
                        string deletePosudbaQuery = "DELETE FROM Posudba WHERE FilmID = @FilmID";
                        using (SqlCommand command = new SqlCommand(deletePosudbaQuery, connection))
                        {
                            command.Parameters.AddWithValue("@FilmID", filmID);
                            command.ExecuteNonQuery();
                        }
                        string deleteRecenzijaQuery = "DELETE FROM Recenzija WHERE FilmID = @FilmID";
                        using (SqlCommand command = new SqlCommand(deleteRecenzijaQuery, connection))
                        {
                            command.Parameters.AddWithValue("@FilmID", filmID);
                            command.ExecuteNonQuery();
                        }
                        string deleteFilmQuery = "DELETE FROM Film WHERE FilmID = @FilmID";
                        using (SqlCommand command = new SqlCommand(deleteFilmQuery, connection))
                        {
                            command.Parameters.AddWithValue("@FilmID", filmID);
                            command.ExecuteNonQuery();
                        }
                        UcitajPodatke();
                        MessageBox.Show("Film je uspješno obrisan!");
                    }
                }
                else
                {
                    MessageBox.Show("Molimo odaberite film za brisanje.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri brisanju podataka: " + ex.Message);
            }
        }

        private void btnVratiFilm_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    string filmID = dataGridView1.SelectedRows[0].Cells["FilmID"].Value.ToString();

                    using (SqlConnection connection = new SqlConnection(ConnString))
                    {
                        connection.Open();
                        string updatePosudbaQuery = "UPDATE Film SET Posuđen = 0 WHERE FilmID = @FilmID";
                        using (SqlCommand command = new SqlCommand(updatePosudbaQuery, connection))
                        {
                            command.Parameters.AddWithValue("@FilmID", filmID);
                            command.ExecuteNonQuery();
                        }
                        UcitajPodatke();
                        MessageBox.Show("Posudba je uspješno vraćena!");
                    }
                }
                else
                {
                    MessageBox.Show("Molimo odaberite film za vraćanje posudbe.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri vraćanju posudbe: " + ex.Message);
            }
        }

        private void btnPosudiFilm_Click(object sender, EventArgs e)
        {
            try
            {
                System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
                System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("hr-HR");

                if (odabraniFilm != null)
                {
                    string ime = "";
                    string prezime = "";
                   
                    ime = Microsoft.VisualBasic.Interaction.InputBox("Unesite Ime korisnika", "Dodaj Korisnika");
                    prezime = Microsoft.VisualBasic.Interaction.InputBox("Unesite Prezime korisnika", "Dodaj Korisnika");

                    bool valjaniEmail = false;
                    string email = "";

                    while (!valjaniEmail)
                    {
                        email = Microsoft.VisualBasic.Interaction.InputBox("Unesite Email korisnika", "Dodaj Korisnika");

                        if (ValjaniEmail(email))
                        {
                            valjaniEmail = true;
                        }
                        else
                        {
                            MessageBox.Show("Neispravan format e-mail adrese. Molimo unesite ispravan format.");
                        }
                    }

                    string[] korisnickiPodaci = { ime, prezime, email };

                    int korisnikID;

                    using (SqlConnection connection = new SqlConnection(ConnString))
                    {
                        connection.Open();

                        korisnikID = provjeriPostojiLiKorisnik(connection, korisnickiPodaci);

                        if (korisnikID == -1)
                        {
                            string insertKorisnikQuery = "INSERT INTO Korisnik (Ime, Prezime, Email) VALUES (@Ime, @Prezime, @Email)";
                            using (SqlCommand command = new SqlCommand(insertKorisnikQuery, connection))
                            {
                                command.Parameters.AddWithValue("@Ime", korisnickiPodaci[0]);
                                command.Parameters.AddWithValue("@Prezime", korisnickiPodaci[1]);
                                command.Parameters.AddWithValue("@Email", korisnickiPodaci[2]);

                                command.ExecuteNonQuery();
                            }
                            korisnikID = dobijZadnjiUmetnutiID(connection);
                        }

                        string datumPosudbeInput = Microsoft.VisualBasic.Interaction.InputBox("Unesite Datum Posudbe (DD.MM.GGGG)", "Posudi Film");
                        if (DateTime.TryParse(datumPosudbeInput, out DateTime datumPosudbe))
                        {
                            string datumVracanjaInput = Microsoft.VisualBasic.Interaction.InputBox("Unesite Datum Vraćanja (DD.MM.GGGG)", "Posudi Film");
                            if (DateTime.TryParse(datumVracanjaInput, out DateTime datumVracanja))
                            {
                                if (datumPosudbe <= datumVracanja)
                                {
                                    DialogResult rezultatOcjenjivanja = MessageBox.Show("Želite li ocijeniti film?", "Ocijeni Film", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                    int ocjena = -1;

                                    if (rezultatOcjenjivanja == DialogResult.Yes)
                                    {
                                        bool valjanaOcjena = false;

                                        while (!valjanaOcjena)
                                        {
                                            string ocjenaInput = Microsoft.VisualBasic.Interaction.InputBox("Unesite Ocjenu filma (1-5)", "Ocijeni Film");

                                            if (int.TryParse(ocjenaInput, out ocjena) && ocjena >= 1 && ocjena <= 5)
                                            {
                                                valjanaOcjena = true;
                                            }
                                            else
                                            {
                                                MessageBox.Show("Neispravna ocjena. Molimo unesite ocjenu između 1 i 5.");
                                            }
                                        }
                                    }

                                    DialogResult rezultatPosudba = MessageBox.Show("Želite li potvrditi posudbu filma?", "Potvrdi Posudbu", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                    if (rezultatPosudba == DialogResult.Yes)
                                    {
                                        string insertFilmQuery = "INSERT INTO Film (FilmID, Naslov, GodinaIzdanja, Posuđen) VALUES (@FilmID, @Naslov, @GodinaIzdanja, @Posuđen)";
                                        using (SqlCommand command = new SqlCommand(insertFilmQuery, connection))
                                        {
                                            command.Parameters.AddWithValue("@FilmID", odabraniFilm.imdbID);
                                            command.Parameters.AddWithValue("@Naslov", odabraniFilm.Title);
                                            command.Parameters.AddWithValue("@GodinaIzdanja", odabraniFilm.Year);
                                            command.Parameters.AddWithValue("@Posuđen", 0);

                                            command.ExecuteNonQuery();
                                        }

                                        string insertPosudbaQuery = "INSERT INTO Posudba (FilmID, KorisnikID, DatumPosudbe, DatumVracanja) VALUES (@FilmID, @KorisnikID, @DatumPosudbe, @DatumVracanja)";
                                        using (SqlCommand command = new SqlCommand(insertPosudbaQuery, connection))
                                        {
                                            command.Parameters.AddWithValue("@FilmID", odabraniFilm.imdbID);
                                            command.Parameters.AddWithValue("@KorisnikID", korisnikID);
                                            command.Parameters.AddWithValue("@DatumPosudbe", datumPosudbe);
                                            command.Parameters.AddWithValue("@DatumVracanja", datumVracanja);

                                            command.ExecuteNonQuery();
                                        }

                                        string updateFilmQuery = "UPDATE Film SET Posuđen = 1 WHERE FilmID = @FilmID";
                                        using (SqlCommand command = new SqlCommand(updateFilmQuery, connection))
                                        {
                                            command.Parameters.AddWithValue("@FilmID", odabraniFilm.imdbID);
                                            command.ExecuteNonQuery();
                                        }

                                        if (ocjena != -1)
                                        {
                                            string insertRecenzijaQuery = "INSERT INTO Recenzija (FilmID, KorisnikID, Ocjena) VALUES (@FilmID, @KorisnikID, @Ocjena)";
                                            using (SqlCommand command = new SqlCommand(insertRecenzijaQuery, connection))
                                            {
                                                command.Parameters.AddWithValue("@FilmID", odabraniFilm.imdbID);
                                                command.Parameters.AddWithValue("@KorisnikID", korisnikID);
                                                command.Parameters.AddWithValue("@Ocjena", ocjena);

                                                command.ExecuteNonQuery();
                                            }
                                        }

                                        UcitajPodatke();
                                        MessageBox.Show("Film je uspješno dodan, korisnik je dodan, posudba je zabilježena!");
                                    }
                                    else
                                    {
                                        MessageBox.Show("Posudba nije potvrđena.");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Neispravni datumi. Datum vraćanja ne može biti prije datuma posudbe.");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Neispravan datum vraćanja. Molimo unesite datum u formatu DD.MM.GGGG.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Neispravan datum posudbe. Molimo unesite datum u formatu DD.MM.GGGG.");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Molimo odaberite film za dodavanje.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri unosu podataka: " + ex.Message);
            }
        }

      /*  private bool SadrziSamoSlova(string input)
        {
            return input.All(char.IsLetter);
        }*/

        private bool ValjaniEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email && email.EndsWith("@gmail.com");
            }
            catch
            {
                return false;
            }
        }

        private void btnAzuriraj_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int selectedRow = dataGridView1.SelectedCells[0].RowIndex;
                int selectedColumn = dataGridView1.SelectedCells[0].ColumnIndex;

                string korisnikID = dataGridView1.Rows[selectedRow].Cells["KorisnikID"].Value.ToString();
                string filmID = dataGridView1.Rows[selectedRow].Cells["FilmID"].Value.ToString();
                string columnName = dataGridView1.Columns[selectedColumn].Name;
                string novaVrijednost = "";

                if (columnName == "Ocjena")
                {
                    novaVrijednost = Microsoft.VisualBasic.Interaction.InputBox($"Unesite novu ocjenu za {columnName} (1-5):", "Ažuriranje", "");
                    if (!int.TryParse(novaVrijednost, out int ocjena) || ocjena < 1 || ocjena > 5)
                    {
                        MessageBox.Show("Neispravna ocjena. Molimo unesite ocjenu između 1 i 5.");
                        return;
                    }
                    using (SqlConnection connection = new SqlConnection(ConnString))
                    {
                        connection.Open();
                        string checkRecenzijaQuery = $"SELECT COUNT(*) FROM Recenzija WHERE FilmID = @FilmID AND KorisnikID = @KorisnikID";
                        using (SqlCommand command = new SqlCommand(checkRecenzijaQuery, connection))
                        {
                            command.Parameters.AddWithValue("@FilmID", filmID);
                            command.Parameters.AddWithValue("@KorisnikID", korisnikID);
                            int recenzijaCount = (int)command.ExecuteScalar();

                            if (recenzijaCount > 0)
                            {
                                string updateRecenzijaQuery = $"UPDATE Recenzija SET Ocjena = @NovaOcjena WHERE FilmID = @FilmID AND KorisnikID = @KorisnikID";
                                using (SqlCommand updateCommand = new SqlCommand(updateRecenzijaQuery, connection))
                                {
                                    updateCommand.Parameters.AddWithValue("@NovaOcjena", ocjena);
                                    updateCommand.Parameters.AddWithValue("@FilmID", filmID);
                                    updateCommand.Parameters.AddWithValue("@KorisnikID", korisnikID);

                                    updateCommand.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                string insertRecenzijaQuery = $"INSERT INTO Recenzija (FilmID, KorisnikID, Ocjena) VALUES (@FilmID, @KorisnikID, @NovaOcjena)";
                                using (SqlCommand insertCommand = new SqlCommand(insertRecenzijaQuery, connection))
                                {
                                    insertCommand.Parameters.AddWithValue("@FilmID", filmID);
                                    insertCommand.Parameters.AddWithValue("@KorisnikID", korisnikID);
                                    insertCommand.Parameters.AddWithValue("@NovaOcjena", ocjena);

                                    insertCommand.ExecuteNonQuery();
                                }
                            }
                        }
                    }
                }
                else if (columnName == "Ime" || columnName == "Prezime" || columnName == "Email")
                {
                    novaVrijednost = Microsoft.VisualBasic.Interaction.InputBox($"Unesite novu vrijednost za {columnName}:", "Ažuriranje", "");

                    if (columnName == "Email" && !ValjaniEmail(novaVrijednost))
                    {
                        MessageBox.Show("Neispravan format email adrese. Molimo unesite ispravan format (npr. ime@primjer.com).");
                        return;
                    }

                    using (SqlConnection connection = new SqlConnection(ConnString))
                    {
                        connection.Open();
                        string updateKorisnikQuery = $"UPDATE Korisnik SET {columnName} = @NovaVrijednost WHERE KorisnikID = @KorisnikID";

                        using (SqlCommand command = new SqlCommand(updateKorisnikQuery, connection))
                        {
                            command.Parameters.AddWithValue("@NovaVrijednost", novaVrijednost);
                            command.Parameters.AddWithValue("@KorisnikID", korisnikID);
                            command.ExecuteNonQuery();
                        }
                    }
                }
                else if (columnName == "DatumPosudbe" || columnName == "DatumVracanja" || columnName == "DatumVraceno")
                {
                    novaVrijednost = Microsoft.VisualBasic.Interaction.InputBox($"Unesite novi datum za {columnName} (format: dd.MM.gggg):", "Ažuriranje", "");

                    if (!DateTime.TryParseExact(novaVrijednost, "dd.MM.gggg", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime noviDatum))
                    {
                        MessageBox.Show("Neispravan format datuma. Molimo unesite datum u formatu dd.MM.gggg.");
                        return;
                    }

                    if (columnName == "DatumVracanja" && DateTime.TryParseExact(dataGridView1.Rows[selectedRow].Cells["DatumPosudbe"].Value.ToString(), "dd.MM.gggg", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime datumPosudbe))
                    {
                        if (noviDatum < datumPosudbe)
                        {
                            MessageBox.Show("Datum vraćanja ne može biti prije datuma posudbe.");
                            return;
                        }
                    }

                    if (columnName == "DatumVraceno" && DateTime.TryParseExact(dataGridView1.Rows[selectedRow].Cells["DatumVracanja"].Value.ToString(), "dd.MM.gggg", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime datumVracanja))
                    {
                        if (noviDatum < datumVracanja)
                        {
                            MessageBox.Show("Datum vraćeno ne može biti prije datuma vraćanja.");
                            return;
                        }
                    }

                    using (SqlConnection connection = new SqlConnection(ConnString))
                    {
                        connection.Open();
                        string updatePosudbaQuery = $"UPDATE Posudba SET {columnName} = @NovaVrijednost WHERE FilmID = @FilmID AND KorisnikID = @KorisnikID";

                        using (SqlCommand command = new SqlCommand(updatePosudbaQuery, connection))
                        {
                            command.Parameters.AddWithValue("@NovaVrijednost", noviDatum.ToString("dd-mm-gggg"));
                            command.Parameters.AddWithValue("@FilmID", filmID);
                            command.Parameters.AddWithValue("@KorisnikID", korisnikID);
                            command.ExecuteNonQuery();
                        }
                    }
                }

                UcitajPodatke();
            }
            else
            {
                MessageBox.Show("Molimo odaberite ćeliju za ažuriranje.");
            }
        }

    private void btnIzvjesce_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.Rows.Count > 0)
                {
                    SaveFileDialog saveFileDialog = new SaveFileDialog();
                    saveFileDialog.Filter = "Text Files|*.txt";
                    saveFileDialog.Title = "Spremi izvješće";
                    saveFileDialog.ShowDialog();

                    if (saveFileDialog.FileName != "")
                    {
                        using (StreamWriter sw = new StreamWriter(saveFileDialog.FileName))
                        {
                            sw.WriteLine("Izvješće o podacima");
                            foreach (DataGridViewRow row in dataGridView1.Rows)
                            {
                                for (int i = 0; i < dataGridView1.Columns.Count; i++)
                                {
                                    string cellValue = row.Cells[i].Value != null ? row.Cells[i].Value.ToString() : "NULL";
                                    sw.Write(cellValue + "\t");
                                }
                                sw.WriteLine();
                            }

                            MessageBox.Show("Izvješće je uspješno stvoreno!");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Nema dostupnih podataka za izradu izvješća.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri stvaranju izvješća: " + ex.Message);
            }
        }

        private void btnVraceno_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    string filmID = dataGridView1.SelectedRows[0].Cells["FilmID"].Value.ToString();

                    using (SqlConnection connection = new SqlConnection(ConnString))
                    {
                        connection.Open();
                        string updateDatumVracenoQuery = "UPDATE Posudba SET DatumVraceno = GETDATE() WHERE FilmID = @FilmID";
                        using (SqlCommand command = new SqlCommand(updateDatumVracenoQuery, connection))
                        {
                            command.Parameters.AddWithValue("@FilmID", filmID);
                            command.ExecuteNonQuery();
                        }
                        string updatePosudbaQuery = "UPDATE Film SET Posuđen = 0 WHERE FilmID = @FilmID";
                        using (SqlCommand command = new SqlCommand(updatePosudbaQuery, connection))
                        {
                            command.Parameters.AddWithValue("@FilmID", filmID);
                            command.ExecuteNonQuery();
                        }
                        UcitajPodatke();
                        MessageBox.Show("Datum vraćanja je uspješno postavljen, a film je označen kao vraćen!");
                    }
                }
                else
                {
                    MessageBox.Show("Molimo odaberite film za postavljanje datuma vraćanja.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri postavljanju datuma vraćanja: " + ex.Message);
            }
        }
    }
}